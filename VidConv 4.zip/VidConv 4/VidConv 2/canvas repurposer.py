from moviepy.editor import VideoFileClip, CompositeVideoClip, TextClip, ColorClip
import textwrap
import os

# Directory containing videos to process
input_directory = "/Volumes/AAKHU/jack doherty mass media/CONTENT STORAGE/jackclips"
output_directory = "/Volumes/AAKHU/jack doherty mass media/instagram accounts/MIXED CONTENT"

# Ensure output directory exists
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Initialize a counter for the video parts
part_counter = 1

# Get list of files in the directory, sorted by modification time
files = [os.path.join(input_directory, f) for f in os.listdir(input_directory) if f.lower().endswith(".mp4")]
files.sort(key=os.path.getmtime)

# Loop through sorted files
for input_path in files:
    filename = os.path.basename(input_path)
    output_path = os.path.join(output_directory, f"repurposed7_{filename}")
    
    try:
        # Load the video
        video = VideoFileClip(input_path)

        # Resize the video to a new resolution, maintaining aspect ratio
        video = video.resize(height=1360)

        # Update the original text to include the current part number
        original_text = f"Clips that actually make me kinda like jack doherty (part {part_counter})"

        # Wrap text to fit within a certain width
        wrapped_text = "\n".join(textwrap.wrap(original_text, width=40))  # Adjust width as needed

        # Create a text clip with the wrapped text using a custom font
        text_clip = TextClip(wrapped_text, fontsize=60, color='black', 
                             font="/Volumes/AAKHU/STAY TALENTED GIRLS/fonts/Mont-ExtraLightDEMO.otf",  # Update this path to your font file
                             align="center", method='caption', size=(video.size[0]-100, None))

        # Set the position of the text on the video
        text_clip = text_clip.set_position(('center', 180)).set_duration(video.duration)

        # Create a white background clip
        background_clip = ColorClip(size=(1080, 1920), color=(255, 255, 255), duration=video.duration)

        # Overlay the video and text on the background
        video = video.set_position(lambda t: ('center', background_clip.size[1] - video.size[1] - 125))
        composite_clip = CompositeVideoClip([background_clip, video, text_clip])

        # Ensure the composite clip retains the original video's audio
        composite_clip.audio = video.audio

        # Write the result to a file
        composite_clip.write_videofile(output_path, codec="libx264", fps=24, audio_codec='aac')
        
        print(f"Processed {filename}")
    
    except Exception as e:
        print(f"Error processing video {filename}: {e}")

    # Increment the part counter for the next video
    part_counter += 1
