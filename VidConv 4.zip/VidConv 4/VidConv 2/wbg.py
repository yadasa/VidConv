import customtkinter
from tkinter import filedialog, simpledialog, messagebox
import threading
from moviepy.editor import VideoFileClip, CompositeVideoClip, TextClip, ColorClip
import textwrap
import os

customtkinter.set_appearance_mode("dark")  # Dark mode for the GUI
customtkinter.set_default_color_theme("blue")  # Blue theme for the GUI

class VideoProcessorGUI(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        self.title("OPM MEDIA")
        self.geometry("800x600")
        self.input_directory = ""
        self.output_directory = ""
        self.custom_caption = "Enter your caption here (part {part})"
        self.font_path = "/Volumes/AAKHU/openmedia/OPM OF/content repurposing/Canvas repurposer/mont font/Mont-HeavyDEMO.otf"  # Update this path to your downloaded font file
        self.processing_thread = None
        self.stop_requested = False

        self.create_widgets()

    def create_widgets(self):
        self.input_dir_button = customtkinter.CTkButton(self, text="Select Mass Videos", command=self.select_input_directory)
        self.input_dir_button.pack(pady=10)

        self.output_dir_button = customtkinter.CTkButton(self, text="Select Output Folder", command=self.select_output_directory)
        self.output_dir_button.pack(pady=10)
 
        self.font_button = customtkinter.CTkButton(self, text="Select Custom Font", command=self.select_font)
        self.font_button.pack(pady=10)

        self.custom_caption_button = customtkinter.CTkButton(self, text="Set Custom Header", command=self.set_custom_caption)
        self.custom_caption_button.pack(pady=10)

        self.start_button = customtkinter.CTkButton(self, text="Start SpiderWeb", command=self.start_processing)
        self.start_button.pack(pady=10)

        self.stop_button = customtkinter.CTkButton(self, text="Stop SpiderWeb", command=self.stop_processing)
        self.stop_button.pack(pady=10)

        self.log = customtkinter.CTkTextbox(self, height=10)
        self.log.pack(pady=20, fill="both", expand=True)

    def select_input_directory(self):
        self.input_directory = filedialog.askdirectory()
        if self.input_directory:
            self.log.insert("end", f"Selected input directory: {self.input_directory}\n")

    def select_output_directory(self):
        self.output_directory = filedialog.askdirectory()
        if self.output_directory:
            self.log.insert("end", f"Selected output directory: {self.output_directory}\n")

    def select_font(self):
        self.font_path = filedialog.askopenfilename()
        if self.font_path:
            self.log.insert("end", f"Selected font: {self.font_path}\n")

    def set_custom_caption(self):
        caption = simpledialog.askstring("Custom Caption", "Enter the custom caption:", initialvalue=self.custom_caption)
        if caption:
            self.custom_caption = caption
            self.log.insert("end", f"Custom caption set: {self.custom_caption}\n")

    def start_processing(self):
        if self.processing_thread and self.processing_thread.is_alive():
            messagebox.showerror("Error", "Processing is already running.")
            return
        if not self.input_directory or not self.output_directory or not self.font_path:
            messagebox.showerror("Error", "Please select input and output directories and a custom font.")
            return

        self.stop_requested = False
        self.processing_thread = threading.Thread(target=self.process_videos, daemon=True)
        self.processing_thread.start()

    def stop_processing(self):
        if self.processing_thread and self.processing_thread.is_alive():
            self.stop_requested = True
            self.log.insert("end", "Stopping processing...\n")

    def process_videos(self):
        if not os.path.exists(self.output_directory):
            os.makedirs(self.output_directory)

        part_counter = 1
        files = [os.path.join(self.input_directory, f) for f in os.listdir(self.input_directory) if f.lower().endswith(".mp4")]
        files.sort(key=os.path.getmtime)

        for input_path in files:
            if self.stop_requested:
                self.log.insert("end", "Processing stopped.\n")
                break

            filename = os.path.basename(input_path)
            output_path = os.path.join(self.output_directory, f"repurposed_{filename}")

            try:
                video = VideoFileClip(input_path)
                video = video.resize(0.7)  # Scale down by 70%

                # Wrap the text as before
                wrapped_text = "\n".join(textwrap.wrap(self.custom_caption.format(part=part_counter), width=40))
                text_clip = TextClip(wrapped_text, fontsize=50, color='black', font=self.font_path, align="center", method='caption', size=(video.size[0]-50, 400))
                text_clip = text_clip.set_position(('center', 100)).set_duration(video.duration)  # Keep text position adjusted as needed

                # Set background clip size to 1080x1920
                background_clip = ColorClip(size=(1080, 1920), color=(255, 255, 255), duration=video.duration)

                # Center the video horizontally and set y position to 1140
                # Assuming '1140' is the intended vertical starting position from the top for the video itself
                video = video.set_position(('center', 400))

                # Set composite clip size to the background size, 1080x1920
                composite_clip = CompositeVideoClip([background_clip, video, text_clip], size=(1080, 1920))
                composite_clip.write_videofile(output_path, codec="libx264", fps=24, audio_codec='aac')

                self.log.insert("end", f"Processed {filename}\n")

            except Exception as e:
                self.log.insert("end", f"Error processing {filename}: {e}\n")

            part_counter += 1
            if self.stop_requested:
                self.log.insert("end", "Processing stopped.\n")
                break

if __name__ == "__main__":
    app = VideoProcessorGUI()
    app.mainloop()