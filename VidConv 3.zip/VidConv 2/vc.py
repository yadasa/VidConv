from moviepy.editor import VideoFileClip, CompositeVideoClip, ImageClip
from PIL import Image, ImageFont, ImageDraw
import numpy as np
import os
import textwrap
import glob  # Import glob for finding all the paths matching a pattern

# Create the output directory if it doesn't exist
output_directory = "/Volumes/AAKHU/VidConv-main/VidConv/outputs"
os.makedirs(output_directory, exist_ok=True)

def process_video(video_pth, dn, twt, usr, rp, qt, lk, bk, p_img_pth, v_ic_pth, o_fn):
    tmpl_pth = "/Volumes/AAKHU/VidConv-main/VidConv/base/twittertemplate.png"
    fnt_rg_pth = "/Volumes/AAKHU/VidConv-main/VidConv/base/chirp-2/ChirpRegular.ttf"
    fnt_bd_pth = "/Volumes/AAKHU/VidConv-main/VidConv/base/chirp-2/ChirpBold.ttf"

    # Load and prepare the template image
    img = Image.open(tmpl_pth).convert("RGBA")
    original_size = img.size
    target_size = (1080, 1920)
    scale = min(target_size[0] / original_size[0], target_size[1] / original_size[1])
    new_size = (int(original_size[0] * scale), int(original_size[1] * scale))
    img = img.resize(new_size, Image.ANTIALIAS)
    drw = ImageDraw.Draw(img)

    # Adjust all positional elements to scale
    p_img = Image.open(p_img_pth).resize((int(150 * scale * 0.9), int(150 * scale * 0.9)))
    msk = Image.new('L', p_img.size, 0)
    msk_drw = ImageDraw.Draw(msk)
    msk_drw.ellipse((0, 0, p_img.width, p_img.height), fill=255)
    p_img.putalpha(msk)
    p_img_pos = (int(57 * scale * 0.9) + 80, int(60 * scale * 0.9) + 220)
    img.paste(p_img, p_img_pos, p_img)

    # Font settings adjusted to scale
    fs_dn = int(52 * scale * 0.9)
    fs_twt = int(46 * scale)  # Keep "twt" scale the same
    fs_usr = int(42 * scale * 0.9)
    fs_sts = int(49 * scale * 0.8)
    fnt_dn = ImageFont.truetype(fnt_bd_pth, fs_dn)
    fnt_twt = ImageFont.truetype(fnt_rg_pth, fs_twt)  # "twt" font unchanged
    fnt_usr = ImageFont.truetype(fnt_rg_pth, fs_usr)
    fnt_sts_bd = ImageFont.truetype(fnt_bd_pth, fs_sts)
    fnt_sts_rg = ImageFont.truetype(fnt_rg_pth, fs_sts)

    # Text positioning and drawing scaled
    dn_pos = (int(240 * scale * 0.9) + 80, int(70 * scale * 0.9) + 225)
    twt_pos = (int(225 * scale) + 50, int(215 * scale * 0.9) + 215)
    wrp_twt_txt = textwrap.fill(twt, width=int(45 * scale))  # Keep "twt" width the same
    drw.text(dn_pos, dn, font=fnt_dn, fill="white")
    drw.text(twt_pos, wrp_twt_txt, font=fnt_twt, fill="white")
    usr_pos = (int(240 * scale * 0.9) + 80, int(120 * scale * 0.9) + 225)
    drw.text(usr_pos, usr, font=fnt_usr, fill="#8899a6")

    # Verified icon processing scaled
    v_ic_sz = int(64 * scale * 0.9)
    v_ic = Image.open(v_ic_pth).resize((v_ic_sz, v_ic_sz))
    v_ic_pos = (dn_pos[0] + fs_dn * len(dn) // 2 + 5, dn_pos[1])
    img.paste(v_ic, v_ic_pos, v_ic)

    # Status values and labels scaled
    sts_x_pos = [int(x * scale) for x in [300, 500, 680, 850]]
    sts_vals = [rp, qt, lk, bk]
    sts_lbls = ["Reposts", "Quotes", "Likes", "Bookmarks"]
    base_sts_y = img.height - int(500 * scale)
    vl_sp = int(30 * scale)
    for i, (v, l) in enumerate(zip(sts_vals, sts_lbls)):
        drw.text((sts_x_pos[i], base_sts_y - 20 - vl_sp), v, font=fnt_sts_bd, fill="white")
        drw.text((sts_x_pos[i], base_sts_y), l, font=fnt_sts_rg, fill="#8899a6")

    # Convert the PIL image to a numpy array and extract RGB and alpha channels
    np_image = np.array(img)
    np_image_rgb = np_image[:, :, :3]
    np_image_alpha = np_image[:, :, 3] / 255.0  # Normalize the mask

    # Load the video clip and resize it
    video_clip = VideoFileClip(video_pth).resize(newsize=(720, 1278))

    # Create a template clip with a mask
    template_clip = ImageClip(np_image_rgb, duration=video_clip.duration).set_mask(ImageClip(np_image_alpha, ismask=True, duration=video_clip.duration))

    # Set the position of the video clip
    video_clip_positioned = video_clip.set_position((200, 400))

    # Overlay the template on the positioned video
    final_clip = CompositeVideoClip([video_clip_positioned, template_clip.set_position('center')], size=(1080, 1920))

    # Set the audio of the composite clip as the video's audio
    final_clip.audio = video_clip.audio
    # Write the result to a file
    final_clip.write_videofile(os.path.join(output_directory, o_fn), codec='libx264', audio_codec='aac')

# Directory containing video files
video_directory = "/Volumes/AAKHU/jack doherty mass media/CONTENT STORAGE/snapchat videos"
video_files = glob.glob(os.path.join(video_directory, '*.MP4'))  # Modify as needed for other video formats

# Iterate over each video in the directory and process it
for video_path in video_files:
    output_file_name = os.path.basename(video_path).replace('.MP4', '_processed.mp4')
    process_video(
        video_pth=video_path,
        dn="jackdfan",
        twt="Jack is a G for this",
        usr="@jack.biggestfan69",
        rp="4.5K",
        qt="200",
        lk="18.9K",
        bk="1.8k",
        p_img_pth="/Volumes/AAKHU/VidConv-main/VidConv/profpics/JackFan Pages/profpic2.png",
        v_ic_pth="/Volumes/AAKHU/VidConv-main/VidConv/base/verified.png",
        o_fn=output_file_name
    )
