import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import os
import random
import string
from vc import twcu
import cv2
import numpy as np
import openai

def rq():
    zf = tk.Tk()
    zf.title("Tweet Customizer")
    zf.geometry("520x600")
    return zf

w = rq()

b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13 = [tk.StringVar() for _ in range(13)]
b12.set(True)
b13.set("manually type caption")

def fx():
    return filedialog.askopenfilename()

def fy():
    return filedialog.askdirectory()

def f1():
    b9.set(fx())

def f2():
    b10.set(fy())

def f3():
    b8.set(fx())

def fr():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=5))

def fc(s):
    try:
        return openai.Completion.create(engine="text-davinci-003", prompt=f"Generate a caption for a video based on the following tweet text: {s}", max_tokens=60).choices[0].text.strip()
    except Exception as e:
        messagebox.showerror("Error", f"Failed to generate caption: {e}")
        return None

def fg():
    return random.choice(["A moment to remember!", "Unforgettable scenes captured on video.", "Watch this amazing moment unfold!"])

def fn():
    if not b10.get():
        messagebox.showerror("Error", "Please select an output directory.")
        return
    if not b9.get():
        messagebox.showerror("Error", "No background media selected.")
        return
    q = b13.get()
    if q == "generate caption from AI":
        c = fc(b1.get())
        if c is None:
            return
        b1.set(c)
    elif q == "generate generic caption":
        b1.set(fg())
    v = [b1, b2, b3, b4, b5, b6, b7]
    for i in v:
        if not i.get().strip():
            i.set(fr())
    t = os.path.join(b10.get(), "customized_tweet.png")
    d = "/Volumes/AAKHU/VidConv-main/VidConv/base/verified.png" if b12.get() else ""
    twcu(dn=b2.get(), twt=b1.get(), usr=b3.get(), rp=b4.get(), qt=b5.get(), lk=b6.get(), bk=b7.get(), p_img_pth=b8.get(), v_ic_pth=d, o_fn=t)
    if b9.get().lower().endswith(('png', 'jpg', 'jpeg')):
        final_img_path = os.path.join(b10.get(), "final_output.png")
        Image.open(t).save(final_img_path)
    elif b9.get().lower().endswith(('mp4', 'avi')):
        final_video_path = os.path.join(b10.get(), "final_output.mp4")
    messagebox.showinfo("Success", "Tweet image has been generated with the background!")

k = ["manually type caption", "generate caption from AI", "generate generic caption"]
tk.OptionMenu(w, b13, *k).pack()
m = {'Tweet Text': b1, 'Display Name': b2, 'Username': b3, '# of Reposts': b4, '# of Quotes': b5, '# of Likes': b6, '# of Bookmarks': b7}
for j, i in m.items():
    tk.Label(w, text=f"{j}:").pack()
    tk.Entry(w, textvariable=i).pack()
tk.Button(w, text="Select Profile Image", command=f3).pack()
tk.Button(w, text="Select Background Media", command=f1).pack()
tk.Button(w, text="Select Output Directory", command=f2).pack()
tk.Checkbutton(w, text="Show Verified Icon", variable=b12).pack()
tk.Button(w, text="Generate Tweet", command=fn).pack()
w.mainloop()
