document.getElementById('tweetForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // 
    const formData = new FormData();
    formData.append('displayName', document.getElementById('displayName').value);
    formData.append('username', document.getElementById('username').value);
    formData.append('tweetText', document.getElementById('tweetText').value);
    formData.append('profileImage', document.getElementById('profileImage').files[0]);
    formData.append('media', document.getElementById('media').files[0]);
    formData.append('reposts', document.getElementById('reposts').value);
    formData.append('bookmarks', document.getElementById('bookmarks').value);
    formData.append('likes', document.getElementById('likes').value);
    formData.append('quotes', document.getElementById('quotes').value);

    // 
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/upload', true);
    xhr.onload = function () {
        if (this.status === 200) {
            alert('Tweet customized successfully!');
            // 
        } else {
            alert('Error processing request!');
        }
    };
    xhr.send(formData);
});
