import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import os
import random
import string
from vc import twcu  # Assuming this is your module for customizing tweets
import cv2
import numpy as np
import openai  # You will need to have OpenAI's Python client installed

# GUI window setup
root = tk.Tk()
root.title("Tweet Customizer")
root.geometry("520x600")

# Variables to hold text input and settings
tweet_text = tk.StringVar()
display_name = tk.StringVar()
username = tk.StringVar()
reposts = tk.StringVar()
quotes = tk.StringVar()
likes = tk.StringVar()
bookmarks = tk.StringVar()
profile_image_path = tk.StringVar()
output_directory = tk.StringVar()
background_media_path = tk.StringVar()
verified_icon_visible = tk.BooleanVar(value=True)
caption_option = tk.StringVar(value="manually type caption")

# Function to select an image or video file for the background
def select_background_media():
    filename = filedialog.askopenfilename()
    background_media_path.set(filename)

# Function to select output directory
def select_output_directory():
    directory = filedialog.askdirectory()
    output_directory.set(directory)

# Function to select an image file for the profile picture
def select_profile_image():
    filename = filedialog.askopenfilename()
    profile_image_path.set(filename)

# Function to generate random alphanumeric string
def random_string():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=5))

# Function to generate a caption using OpenAI's API
def generate_caption(input_text):
    try:
        response = openai.Completion.create(
            engine="text-davinci-003", 
            prompt=f"Generate a caption for a video based on the following tweet text: {input_text}", 
            max_tokens=60
        )
        return response.choices[0].text.strip()
    except Exception as e:
        messagebox.showerror("Error", f"Failed to generate caption: {e}")
        return None

# Function to generate a generic caption
def generate_generic_caption():
    generic_prompts = [
        "A moment to remember!", "Unforgettable scenes captured on video.", "Watch this amazing moment unfold!"
    ]
    return random.choice(generic_prompts)

# Function to generate the tweet image and handle the background
def generate_tweet():
    if not output_directory.get():
        messagebox.showerror("Error", "Please select an output directory.")
        return

    if not background_media_path.get():
        messagebox.showerror("Error", "No background media selected.")
        return

    # Determine the caption based on the dropdown selection
    selected_option = caption_option.get()
    if selected_option == "generate caption from AI":
        caption = generate_caption(tweet_text.get())
        if caption is None:
            return  # Early exit if the caption generation fails
        tweet_text.set(caption)
    elif selected_option == "generate generic caption":
        caption = generate_generic_caption()
        tweet_text.set(caption)

    # Fill in empty fields with random data
    fields = [tweet_text, display_name, username, reposts, quotes, likes, bookmarks]
    for field in fields:
        if not field.get().strip():
            field.set(random_string())

    # Generate the tweet image
    tweet_image_path = os.path.join(output_directory.get(), "customized_tweet.png")
    verified_icon_path = "D:/Users/itsst/Documents/WORK/Jack/code/VidConv/base/verified.png" if verified_icon_visible.get() else ""
    twcu(
        display_name=display_name.get(),
        tweet=tweet_text.get(),
        username=username.get(),
        reposts=reposts.get(),
        quotes=quotes.get(),
        likes=likes.get(),
        bookmarks=bookmarks.get(),
        profile_image_path=profile_image_path.get(),
        verified_icon_path=verified_icon_path,
        output_filename=tweet_image_path
    )

    # Resize the background and finalize the image or video
    if background_media_path.get().lower().endswith(('png', 'jpg', 'jpeg')):
        background_img = resize_background(background_media_path.get(), tweet_image_path)
        final_img = finalize_image(background_img, tweet_image_path)
        final_output_path = os.path.join(output_directory.get(), "final_output.png")
        final_img.save(final_output_path)
    elif background_media_path.get().lower().endswith(('mp4', 'avi')):
        final_video_path = os.path.join(output_directory.get(), "final_output.mp4")
        process_video_background(background_media_path.get(), tweet_image_path, final_video_path)

    messagebox.showinfo("Success", "Tweet image has been generated with the background!")

# Dropdown for caption options
caption_options = ["manually type caption", "generate caption from AI", "generate generic caption"]
caption_menu = tk.OptionMenu(root, caption_option, *caption_options)
caption_menu.pack()

# Layout
fields = {
    'Tweet Text': tweet_text,
    'Display Name': display_name,
    'Username': username,
    '# of Reposts': reposts,
    '# of Quotes': quotes,
    '# of Likes': likes,
    '# of Bookmarks': bookmarks
}

for field, var in fields.items():
    tk.Label(root, text=f"{field}:").pack()
    tk.Entry(root, textvariable=var).pack()

tk.Button(root, text="Select Profile Image", command=select_profile_image).pack()
tk.Button(root, text="Select Background Media", command=select_background_media).pack()
tk.Button(root, text="Select Output Directory", command=select_output_directory).pack()
tk.Checkbutton(root, text="Show Verified Icon", variable=verified_icon_visible).pack()
tk.Button(root, text="Generate Tweet", command=generate_tweet).pack()

# Start the GUI
root.mainloop()