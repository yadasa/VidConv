import tkinter as gui
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import os
import random
import string
from vc import twcu  
import cv2
import numpy as np

main = gui.Tk()
main.title("Tweet Customizer")


txt, dn, un, reps, qt, lk, bkm, p_img, o_dir, bkg_media, v_icon = [gui.StringVar() for _ in range(11)]
v_icon.set(True)


def s_bkg_media():
    bkg_media.set(filedialog.askopenfilename())


def s_o_dir():
    o_dir.set(filedialog.askdirectory())

def s_p_img():
    p_img.set(filedialog.askopenfilename())

def r_str():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=5))


def adj_bkg(b_path, o_path):
    o_img = Image.open(o_path)
    o_w, o_h = o_img.size

    if b_path.lower().endswith(('mp4', 'avi')):
        return None 
    b_img = Image.open(b_path)
    b_w, b_h = b_img.size
    b_ratio = b_w / b_h
    o_ratio = o_w / o_h

    if b_ratio > o_ratio:
        s_h = o_h
        s_w = int(s_h * b_ratio)
    else:
        s_w = o_w
        s_h = int(s_w / b_ratio)

    b_img = b_img.resize((s_w, s_h), Image.LANCZOS)
    l = (s_w - o_w) // 2
    t = (s_h - o_h) // 2

    return b_img.crop((l, t, l + o_w, t + o_h))


def f_img(b_img, o_img_path):
    o_img = Image.open(o_img_path)
    b_img.paste(o_img, (0, 0), o_img if o_img.mode == 'RGBA' else None)
    return b_img


def proc_vid(b_path, o_img_path, o_path):
    cap = cv2.VideoCapture(b_path)
    fw = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    fh = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    out = cv2.VideoWriter(o_path, cv2.VideoWriter_fourcc(*'mp4v'), cap.get(cv2.CAP_PROP_FPS), (fw, fh))

    o_img = Image.open(o_img_path).resize((fw, fh), Image.LANCZOS)
    o_mask = o_img.convert("RGBA")

    while True:
        ret, frm = cap.read()
        if not ret:
            break
        frm_img = Image.fromarray(cv2.cvtColor(frm, cv2.COLOR_BGR2RGB))
        frm_img.paste(o_mask, (0, 0), o_mask)
        frm_res = cv2.cvtColor(np.array(frm_img), cv2.COLOR_RGB2BGR)
        out.write(frm_res)

    cap.release()
    out.release()


def gen_tweet():
    if not o_dir.get():
        messagebox.showerror("Error", "No output directory selected.")
        return

    if not bkg_media.get():
        messagebox.showerror("Error", "No background media selected.")
        return

    fields = [txt, dn, un, reps, qt, lk, bkm]
    for f in fields:
        if not f.get().strip():
            f.set(r_str())

    t_path = os.path.join(o_dir.get(), "customized_tweet.png")
    v_path = "D:/path/to/verified.png" if v_icon.get() else ""
    twcu(display_name=dn.get(), tweet=txt.get(), username=un.get(), reposts=reps.get(), quotes=qt.get(),
                    likes=lk.get(), bookmarks=bkm.get(), profile_image_path=p_img.get(), verified_icon_path=v_path,
                    output_filename=t_path)

    if bkg_media.get().lower().endswith(('png', 'jpg', 'jpeg')):
        b_img = adj_bkg(bkg_media.get(), t_path)
        f_img = f_img(b_img, t_path)
        f_img.save(os.path.join(o_dir.get(), "final_output.png"))
    elif bkg_media.get().lower().endswith(('mp4', 'avi')):
        proc_vid(bkg_media.get(), t_path, os.path.join(o_dir.get(), "final_output.mp4"))

    messagebox.showinfo("Success", "Tweet image generated with the background!")


fields = {
    'Tweet Text': txt,
    'Display Name': dn,
    'Username': un,
    '# of Reposts': reps,
    '# of Quotes': qt,
    '# of Likes': lk,
    '# of Bookmarks': bkm
}

for f, v in fields.items():
    gui.Label(main, text=f"{f}:").pack()
    gui.Entry(main, textvariable=v).pack()

gui.Button(main, text="Select Profile Image", command=s_p_img).pack()
gui.Button(main, text="Select Background Media", command=s_bkg_media).pack()
gui.Button(main, text="Select Output Directory", command=s_o_dir).pack()
gui.Checkbutton(main, text="Show Verified Icon", variable=v_icon).pack()
gui.Button(main, text="Generate Tweet", command=gen_tweet).pack()

main.mainloop()
