import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import os
import random
import string
from vc import customize_tweet  # Assuming this is your module for customizing tweets
import cv2
import numpy as np
from moviepy.editor import VideoFileClip, AudioFileClip, CompositeVideoClip


# GUI window setup
root = tk.Tk()
root.title("Tweet Customizer")

# Variables to hold text input and settings
tweet_text = tk.StringVar()
display_name = tk.StringVar()
username = tk.StringVar()
reposts = tk.StringVar()
quotes = tk.StringVar()
likes = tk.StringVar()
bookmarks = tk.StringVar()
profile_image_path = tk.StringVar()
output_directory = tk.StringVar()
background_media_path = tk.StringVar()
verified_icon_visible = tk.BooleanVar(value=True)

# Function to select an image or video file for the background
def select_background_media():
    filename = filedialog.askopenfilename()
    background_media_path.set(filename)

# Function to select output directory
def select_output_directory():
    directory = filedialog.askdirectory()
    output_directory.set(directory)

# Function to select an image file for the profile picture
def select_profile_image():
    filename = filedialog.askopenfilename()
    profile_image_path.set(filename)

# Function to generate random alphanumeric string
def random_string():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=5))

# Function to resize and match the background to the tweet template while maintaining aspect ratio
def resize_background(background_path, overlay_path):
    overlay_img = Image.open(overlay_path)
    overlay_width, overlay_height = overlay_img.size

    if background_path.lower().endswith(('mp4', 'avi')):
        # For video files, handle them separately
        return None  # This will be handled in the video processing part

    # Load background image and calculate ratio
    background = Image.open(background_path)
    bg_width, bg_height = background.size
    bg_ratio = bg_width / bg_height
    overlay_ratio = overlay_width / overlay_height

    if bg_ratio > overlay_ratio:
        # Wider than needed, scale by height
        scale_height = overlay_height
        scale_width = int(scale_height * bg_ratio)
    else:
        # Taller than needed, scale by width
        scale_width = overlay_width
        scale_height = int(scale_width / bg_ratio)

    # Resize the image
    background = background.resize((scale_width, scale_height), Image.LANCZOS)

    # Center the image
    left = (scale_width - overlay_width) // 2
    top = (scale_height - overlay_height) // 2
    right = left + overlay_width
    bottom = top + overlay_height

    background = background.crop((left, top, right, bottom))
    return background

# Function to overlay the customized tweet onto the resized background
def finalize_image(background_img, overlay_img_path):
    overlay_img = Image.open(overlay_img_path)
    background_img.paste(overlay_img, (0, 0), overlay_img if overlay_img.mode == 'RGBA' else None)
    return background_img

# Function to process video backgrounds
def process_video_background(video_path, overlay_img_path, output_path):
    # Capture video properties
    cap = cv2.VideoCapture(video_path)
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)

    # Define the codec and create VideoWriter object
    fourcc = cv2.VideoWriter_fourcc(*'X264')
    temp_video_path = "temp_output.mp4"  # Temporary path for video without audio
    out = cv2.VideoWriter(temp_video_path, fourcc, fps, (frame_width, frame_height))

    overlay_img = Image.open(overlay_img_path)
    overlay_img = overlay_img.resize((frame_width, frame_height), Image.LANCZOS)
    overlay_mask = overlay_img.convert("RGBA")

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        frame_image.paste(overlay_mask, (0, 0), overlay_mask)
        frame_result = cv2.cvtColor(np.array(frame_image), cv2.COLOR_RGB2BGR)
        out.write(frame_result)

    cap.release()
    out.release()

    # Add original audio to the video using moviepy
    original_video = VideoFileClip(video_path)
    processed_video = VideoFileClip(temp_video_path)
    final_video = processed_video.set_audio(original_video.audio)
    final_video.write_videofile(output_path, codec='libx264')

    # Optionally remove the temporary video file
    import os
    os.remove(temp_video_path)

# Function to generate the tweet image and handle the background
def generate_tweet():
    if not output_directory.get():
        messagebox.showerror("Error", "Please select an output directory.")
        return

    if not background_media_path.get():
        messagebox.showerror("Error", "No background media selected.")
        return

    # Fill in empty fields with random data
    fields = [tweet_text, display_name, username, reposts, quotes, likes, bookmarks]
    for field in fields:
        if not field.get().strip():
            field.set(random_string())

    # Generate the tweet image
    tweet_image_path = os.path.join(output_directory.get(), "customized_tweet.png")
    verified_icon_path = "D:/Users/itsst/Documents/WORK/Jack/code/VidConv/base/verified.png" if verified_icon_visible.get() else ""
    customize_tweet(
        display_name=display_name.get(),
        tweet=tweet_text.get(),
        username=username.get(),
        reposts=reposts.get(),
        quotes=quotes.get(),
        likes=likes.get(),
        bookmarks=bookmarks.get(),
        profile_image_path=profile_image_path.get(),
        verified_icon_path=verified_icon_path,
        output_filename=tweet_image_path
    )

    # Resize the background and finalize the image or video
    if background_media_path.get().lower().endswith(('png', 'jpg', 'jpeg')):
        background_img = resize_background(background_media_path.get(), tweet_image_path)
        final_img = finalize_image(background_img, tweet_image_path)
        final_output_path = os.path.join(output_directory.get(), "final_output.png")
        final_img.save(final_output_path)
    elif background_media_path.get().lower().endswith(('mp4', 'avi')):
        final_video_path = os.path.join(output_directory.get(), "final_output.mp4")
        process_video_background(background_media_path.get(), tweet_image_path, final_video_path)

    messagebox.showinfo("Success", "Tweet image has been generated with the background!")

# Layout
fields = {
    'Tweet Text': tweet_text,
    'Display Name': display_name,
    'Username': username,
    '# of Reposts': reposts,
    '# of Quotes': quotes,
    '# of Likes': likes,
    '# of Bookmarks': bookmarks
}

for field, var in fields.items():
    tk.Label(root, text=f"{field}:").pack()
    tk.Entry(root, textvariable=var).pack()

tk.Button(root, text="Select Profile Image", command=select_profile_image).pack()
tk.Button(root, text="Select Background Media", command=select_background_media).pack()
tk.Button(root, text="Select Output Directory", command=select_output_directory).pack()
tk.Checkbutton(root, text="Show Verified Icon", variable=verified_icon_visible).pack()
tk.Button(root, text="Generate Tweet", command=generate_tweet).pack()

# Start the GUI
root.mainloop()
