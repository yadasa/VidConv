from PIL import Image, ImageFont, ImageDraw, ImageOps
import os
import textwrap

output_directory = "D:/Users/itsst/Documents/WORK/Jack/code/VidConv/outputs"
os.makedirs(output_directory, exist_ok=True)

def twcu(dn, twt, usr, rp, qt, lk, bk, p_img_pth, v_ic_pth, o_fn="output.png"):
    tmpl_pth = "D:/Users/itsst/Documents/WORK/Jack/code/VidConv/base/template.png"
    fnt_rg_pth = "D:/Users/itsst/Documents/WORK/Jack/code/VidConv/base/chirp-2/ChirpRegular.ttf"
    fnt_bd_pth = "D:/Users/itsst/Documents/WORK/Jack/code/VidConv/base/chirp-2/ChirpBold.ttf"

    img = Image.open(tmpl_pth)
    drw = ImageDraw.Draw(img)

    p_img = Image.open(p_img_pth).resize((150, 150))
    msk = Image.new('L', (150, 150), 0)
    msk_drw = ImageDraw.Draw(msk)
    msk_drw.ellipse((0, 0, 150, 150), fill=255)
    p_img.putalpha(msk)

    p_img_pos = (57, 60)

    img.paste(p_img, p_img_pos, p_img)

    fs_dn = 52
    fs_twt = 46
    fs_usr = 42
    fs_sts = 49

    fnt_dn = ImageFont.truetype(fnt_bd_pth, fs_dn)
    fnt_twt = ImageFont.truetype(fnt_rg_pth, fs_twt)
    fnt_usr = ImageFont.truetype(fnt_rg_pth, fs_usr)
    fnt_sts_bd = ImageFont.truetype(fnt_bd_pth, fs_sts)
    fnt_sts_rg = ImageFont.truetype(fnt_rg_pth, fs_sts)

    dn_pos = (240, 70)
    twt_pos = (225, 215)
    usr_pos = (240, 120)

    twt_w = int(img.size[0] * 0.85)
    wrp_twt_txt = textwrap.fill(twt, width=55)
    twt_pos = (twt_pos[0] - 162, twt_pos[1] + 33)

    drw.text(dn_pos, dn, font=fnt_dn, fill="white")
    drw.text(twt_pos, wrp_twt_txt, font=fnt_twt, fill="white")
    drw.text(usr_pos, usr, font=fnt_usr, fill="#8899a6")

    v_ic_sz = 64
    v_ic = Image.open(v_ic_pth).resize((v_ic_sz, v_ic_sz))
    v_ic_pos = (dn_pos[0] + fs_dn * len(dn) // 2 + 5, dn_pos[1])

    img.paste(v_ic, v_ic_pos, v_ic)

    sts_x_pos = [69, 333, 672, 940]
    sts_vals = [rp, qt, lk, bk]
    sts_lbls = ["Reposts", "Quotes", "Likes", "Bookmarks"]
    base_sts_y = img.size[1] - 280
    vl_sp = 30

    for i, (v, l) in enumerate(zip(sts_vals, sts_lbls)):
        drw.text((sts_x_pos[i], base_sts_y - 20 - vl_sp), v, font=fnt_sts_bd, fill="white")
        drw.text((sts_x_pos[i], base_sts_y), l, font=fnt_sts_rg, fill="#8899a6")

    opth = os.path.join(output_directory, o_fn)
    img.save(opth)

twcu(
    dn="Your Display Name",
    twt="Hello World",
    usr="@yourusername",
    rp="1K",
    qt="400",
    lk="3K",
    bk="500",
    p_img_pth="D:/Users/itsst/Documents/WORK/Jack/code/VidConv/base/profile.jpg",
    v_ic_pth="D:/Users/itsst/Documents/WORK/Jack/code/VidConv/base/verified.png",
    o_fn="customized_tweet.png"
)